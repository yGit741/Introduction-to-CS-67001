#################################################################
# FILE : additional_file.py
# WRITER : Yonatan Greenshpan  , yonatan_green , 204266191
# EXERCISE : intro2cs2 ex1 2020
# DESCRIPTION: A simple program that make some basic math
# STUDENTS I DISCUSSED THE EXERCISE WITH: no one.
#								 	      Daffy Duck, duck_daffy.
# WEB PAGES I USED: www.looneytunes.com/lola_bunny
# NOTES: ...
#################################################################
def secret_function():
    print( 'My username is yonatan_green and I know I have to read the submission response.')

if __name__ == "__main__":
    secret_function()
